// Tests for the JavaScriptMVC compatibility layer. Will be removed eventually
steal('steal-qunit', 'jquerypp/controller/view/test/qunit'
	, 'jquerypp/class/class_test.js'
	, 'jquerypp/model/test/qunit'
	, 'jquerypp/controller/controller_test.js'
	, 'jquerypp/view/test/qunit'
	, 'jquerypp/dom/route/route_test.js'
	, './integration.js');