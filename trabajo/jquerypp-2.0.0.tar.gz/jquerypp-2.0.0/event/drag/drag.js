steal('jquery', 'jquerypp/event/drag/core', 'jquerypp/event/drag/step', 'jquerypp/event/drag/limit',
	'jquerypp/event/drag/scroll', function( $ ) {
		return $;
});