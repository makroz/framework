// loads all of jquerymx's command line tests

//load("jquerypp/download/test/run.js");

load('jquerypp/view/test/compression/run.js');

load("jquerypp/generate/test/run.js");

