@constructor jQuery.fn.cookie jQuery.cookie
@page jQuery.fn.cookie
@parent dom
