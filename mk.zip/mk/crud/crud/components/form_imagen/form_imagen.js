Mk_Componentes.add({
  name:'imagen',
  type:'c-form_imagen',
  icon:'image',
  color:'red', 
  isItem:1
});