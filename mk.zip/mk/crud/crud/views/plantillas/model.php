<?php 
class //<<[CLASS]>>// extends //<<[CLASS_EXTENDS]>>//
{

//<<[CAMPOS]>>//

public function __construct($options = array())
	{
		parent::__construct($options);

//<<[JOINS]>>//
	}
}

//version MK.CRUD 1.0 
?>