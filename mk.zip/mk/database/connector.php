<?php
namespace Mk\Database
{
	use Mk\Base as Base;
	//use Mk\Database\Exception as Exception;
	class Connector extends Base
	{
		public function initialize()
		{
			return $this;
		}
	}
}

?>