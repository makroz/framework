<?php
namespace Mk\Cache
{
	use Mk\Base as Base;
	//use Mk\Cache\Exception as Exception;
	class Driver extends Base
	{
		public function initialize()
		{
			return $this;
		}
	}
}

?>